
from rasa_sdk.forms import FormAction
import re
from rasa_sdk import Action, Tracker
import requests
import json
from rasa_sdk.events import SlotSet
from rasa_sdk.executor import CollectingDispatcher
from typing import Any, Text, Dict, List,Any,Union, Optional
from rasa_sdk.events import (
    UserUtteranceReverted,
    Restarted,
    EventType,
    FollowupAction,
    ActionReverted
)
from datetime import datetime as dt


class ActionValidate(Action):
    """Enter the serial  Extractions"""
    
    def name(self):
        return "action_validate"
    def run(self,dispatcher,tracker,domain): 
        # serial = tracker.get_slot('Serial_Number')
        serial1="1"
        date1= "28-10-20"
        time1= "(2 PM - 4 PM)"
        serial2= "2"
        date2= "30-10-20"
        time2="(1 PM - 4 PM)"
        serial3= "3"
        date3= "04-11-20"
        time3="(10 AM - 2 PM)"
        # dispatcher.utter_message("Based on your application information, we have following dates are available. Please select one on") 
        out_message1=("{}) {} {}.".format(serial1 ,date1, time1))
        out_message2=("{}) {} {}.".format(serial2 ,date2, time2))
        out_message3=("{}) {} {}.".format(serial3 ,date3, time3))
        dispatcher.utter_message(out_message1)
        dispatcher.utter_message(out_message2)
        dispatcher.utter_message(out_message3)


class ActionSerialNumber(Action):
# """ This is for restarting the chat"""
    
    def name(self):
        return "action_serial_number"

    def run(self, dispatcher, tracker, domain):
        serial = tracker.get_slot('phone_no')
        print(serial)
        print(type(serial))
        k=int(serial)
        print("k is",k)
        if (k>3 or k==0):
            dispatcher.utter_message(template="Utter_validateSlNO")
            return [UserUtteranceReverted()]
            
        else:
            if(k==1):
                dispatcher.utter_message("1) 28-10-20 (2 PM - 4 PM)")
            elif(k==2):
                dispatcher.utter_message("2) 30-10-20 (1 PM - 4 PM)")
            else:
                dispatcher.utter_message("3. 04-11-20 (10 AM - 2 PM)")
            dispatcher.utter_message(template="utter_confirm_slot")
            
            



class ActionRestarted(Action):
# """ This is for restarting the chat"""

    def name(self):
        return "action_restart"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message(template ="utter_main")
        return [Restarted()]

class ActionFeedBack(Action):
    """Business Email Extractions"""
    

    def name(self):
        return "action_feedback"
    
    def run(self,dispatcher,tracker,domain):
        dispatcher.utter_message("Thank you for the feedback")
        return()  

class CandidateAssesment(Action):
    """Business Email Extractions"""
    

    def name(self):
        return "action_candidate_assesment"
    
    def run(self,dispatcher,tracker,domain):
        dispatcher.utter_message(template ="utter_candidate_assesment")
        return() 

class ActionApplicationstatus(Action):
    """Business Email Extractions"""
    

    def name(self):
        return "actions_application_status"
    
    def run(self,dispatcher,tracker,domain):
        dispatcher.utter_message("Thank you for contacting us Mr. Thames.") 
        dispatcher.utter_message("Your application for the Position of Software Consultant is in process. Our team will contact you soon.")
        return()


class ActionJobOpening(Action):
# """ This is for restarting the chat"""

    def name(self):
        return "action_job_opening"
        
    def run(self,dispatcher,tracker,domain):
        job_opening=tracker.get_slot('quickreply_value4')

        if(job_opening=="PHP"):
            dispatcher.utter_message("Following positions are vacant in PHP.")
            dispatcher.utter_message("1) Software Engineer (1-3 Years Exp) , Job ID-123")
            dispatcher.utter_message("2) Sr Software Engineer (4-7 Years Exp), Job ID-456")
            dispatcher.utter_message("3) Team Lead (8-12 Years Exp), Job ID-567")
            dispatcher.utter_message(template="utter_select_which_position")
        elif(job_opening=="Python"):
            dispatcher.utter_message("Following positions are vacant in Python.")
            dispatcher.utter_message("1) Software Engineer (1-3 Years Exp) , Job ID-123")
            dispatcher.utter_message("2) Sr Software Engineer (4-7 Years Exp), Job ID-456")
            dispatcher.utter_message("3) Team Lead (8-12 Years Exp), Job ID-567")
            dispatcher.utter_message(template="utter_select_which_position")
        elif(job_opening=="UI/UX"):
            dispatcher.utter_message("Following positions are vacant in UI/UX.")
            dispatcher.utter_message("1) Software Engineer (1-3 Years Exp) , Job ID-123")
            dispatcher.utter_message("2) Sr Software Engineer (4-7 Years Exp), Job ID-456")
            dispatcher.utter_message("3) Team Lead (8-12 Years Exp), Job ID-567")
            dispatcher.utter_message(template="utter_select_which_position")
        else:
            dispatcher.utter_message("Following positions are vacant in QA/Testing.")
            dispatcher.utter_message("1) Software Engineer (1-3 Years Exp) , Job ID-123")
            dispatcher.utter_message("2) Sr Software Engineer (4-7 Years Exp), Job ID-456")
            dispatcher.utter_message("3) Team Lead (8-12 Years Exp), Job ID-567")
            dispatcher.utter_message(template="utter_select_which_position")
            


class ActionSelectJobPosition(Action):
    """Business Email Extractions"""
    def name(self):
        return "action_select_job_position"
    def run(self,dispatcher,tracker,domain): 
        value=tracker.get_slot('phone_no')
        if(value=="123" or "456"  or  "567"):
            dispatcher.utter_message(template="want_apply")
        else:
            dispatcher.utter_message(template="utter_valid_job_id")
            return [UserUtteranceReverted()]
        
                    
         
        
class ActionBusinessEmail(Action):
    """Business Email Extractions"""
    def name(self):

        return "action_business_email"
    def run(self,dispatcher,tracker,domain):
        value=tracker.get_slot('business_email')
        print(value)
        if re.match(r"[a-zA-Z0-9_.+-]+@[a-zA-Z]+\.[^@]+",str(value)):
            dispatcher.utter_message(template="utter_phone_no")
        else:
            # no entity was picked up, we want to ask again
            print("inside else")
            dispatcher.utter_message(template="utter_no_email")
            return [UserUtteranceReverted()]
            
class ActionPhoneNumber(Action):
    """Phone Number Extractions"""
    def name(self):
        return "action_phoneNumber"
    def run(self,dispatcher,tracker,domain):
        value=tracker.get_slot('phone_no')
        if re.match(r"^[\d]{2,4}[- ]?[\d]{3}[- ]?[\d]{3,5}|([0])?(\+\d{1,2}[- ]?)?[789]{1}\d{9}$",str(value)):
            # print("inside if")
            # dispatcher.utter_message(text="valid phone_no entered")
            # entity was picked up, validate slot
            # phone_no = tracker.get_slot("phone_no")
            dispatcher.utter_message(template="utter_otp")
    
        else:
            # no entity was picked up, we want to ask again
            print("inside else")
            dispatcher.utter_message(template="utter_no_phone_no")
            return [UserUtteranceReverted()]



class ActionAAdherCard(Action):
    """Phone Number Extractions"""
    def name(self):
        return "action_aadher_card"
        
    def run(self,dispatcher,tracker,domain):  
        aadhaar_number= tracker.get_slot('phone_no')
        if re.match(r'(\d{4})-(\d{4})-(\d{4})',str(aadhaar_number)):
            dispatcher.utter_message(template="utter_pan_number")
        else:
            dispatcher.utter_message(template="utter_no_aadher_card")
            return [UserUtteranceReverted()]
            
class ActionPfNumber(Action):
    """Phone Number Extractions"""
    def name(self):
        return "action_Pf_number"
        
    def run(self,dispatcher,tracker,domain):  
        pf_number= tracker.get_slot('phone_no')
        if re.match(r'^[A-Z]{2}/[A-Z]{3}/\d{7}/\d{3}/\d{7}$',str(pf_number)):
            dispatcher.utter_message(template="utter_onboard_thanks")
        else:
            dispatcher.utter_message(template="utter_no_Pf_number")
            return [UserUtteranceReverted()]
            
class ActionPanNumber(Action):
    """Phone Number Extractions"""
    def name(self):
        return "action_Pan_number"
        
    def run(self,dispatcher,tracker,domain):  
        pan_number= tracker.get_slot('phone_no')
        if re.match(r'[A-Z]{5}[0-9]{4}[A-Z]{1}',str(pan_number)):
           dispatcher.utter_message(template="utter_pf_number")
        else:
            dispatcher.utter_message(template="utter_no_Pan_number")
            return [UserUtteranceReverted()]
            

class ActionInternalJobPostings(Action):
    """Phone Number Extractions"""
    def name(self):
        return "action_internal_job_Postings"  
    
    def run(self,dispatcher,tracker,domain): 
        job= tracker.get_slot('quickreply_value21')    
        job1= tracker.get_slot('quickreply_value22')
        job2= tracker.get_slot('quickreply_value23')
        job3= tracker.get_slot('quickreply_value24')
        job4= tracker.get_slot('quickreply_value25')
        
        if(job=="Medical_Officer" and job1=="Get_job_description"):
            dispatcher.utter_message(template = "utter_Medical_job_description")
        
        
        elif(job=="Network_Manager" and job2=="Get_job_description"):
            dispatcher.utter_message(template = "utter_Network_job_description")
            
        elif(job=="Data_Scientist" and job3=="Get_job_description"):
            dispatcher.utter_message(template ="utter_Data_Scientist_job_description")
        
        elif(job=="Jr.DevOps" and job4=="Get_job_description"):
            dispatcher.utter_message(template = "utter_DevOps_job_description")
        
        
        elif(job1 == "Apply_for_job" or job2 == "Apply_for_job" or  job3 == "Apply_for_job" or job4 == "Apply_for_job"):
            dispatcher.utter_message(template = "utter_Apply_for_job")
          
        else:
            dispatcher.utter_message(template = "utter_Get_Referral_link")

        return()
        
class ActionPolicyValidate(Action):
    """Enter the serial  Extractions"""
    
    def name(self):
        return "action_policy_validate"
    def run(self,dispatcher,tracker,domain): 
        # serial = tracker.get_slot('Serial_Number')
        dispatcher.utter_message("Here is the list of available policies")
        serial1="1"
        Policie1= "Leave Policies"
        serial2= "2"
        Policie2= "Work from Home Policy"
        serial3= "3"
        Policie3= "BYOD Policy"
        serial4= "4"
        Policie4= "Medical Policy"
        serial5= "5"
        Policie5= "Life Insurance Policy"
        # dispatcher.utter_message("Based on your application information, we have following dates are available. Please select one on") 
        out_message1=("{}) {}.".format(serial1 ,Policie1))
        out_message2=("{}) {}.".format(serial2 ,Policie2))
        out_message3=("{}) {}.".format(serial3 ,Policie3))
        out_message4=("{}) {}.".format(serial4 ,Policie4))
        out_message5=("{}) {}.".format(serial5 ,Policie5))
        dispatcher.utter_message(out_message1)
        dispatcher.utter_message(out_message2)
        dispatcher.utter_message(out_message3)
        dispatcher.utter_message(out_message4)
        dispatcher.utter_message(out_message5)


class ActionPolicyNumber(Action):
# """ This is for restarting the chat"""
    
    def name(self):
        return "action_policy_number"

    def run(self, dispatcher, tracker, domain):
        serial = tracker.get_slot('phone_no')
        print(serial)
        print(type(serial))
        k=int(serial)
        if (k>5 or k==0):
            dispatcher.utter_message("Please enter the valid Serial Number")
            return [UserUtteranceReverted()]
            
        else:
            if(k==1):
                dispatcher.utter_message("Leave Policies")
            elif(k==2):
                dispatcher.utter_message("Work from Home Policy")
            elif(k==3):
                dispatcher.utter_message("BYOD Policy")
            elif(k==4):
                dispatcher.utter_message("Medical Policy")
            else:
                dispatcher.utter_message("Life Insurance Policy")
            dispatcher.utter_message(template="policy_link")


class ActionCompleteExitProcess(Action):
# """ Complete Exit Process"""

    def name(self):
        return "action_complete_exit_process"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("Thank you for contacting us Mr. Thames. The following exit formalities are pending")
        dispatcher.utter_message("1) Get NOC from HR")
        dispatcher.utter_message("2) Get NOC from Networking Team")
        dispatcher.utter_message("3) Get Accounts NOC")
        dispatcher.utter_message("4) Take Exit Interview")
        dispatcher.utter_message("5) Return Id card")
        return()    

class ActionUploadRembursmentProofs(Action):
# """ Complete Exit Process"""

    def name(self):
        return "action_Upload_Rembursment_Proofs"

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("Thank you for contacting us Mr. Thames. Please tell us type of bill you wants reimburse?")
        dispatcher.utter_message("1) Mobile")
        dispatcher.utter_message("2) Internet")
        dispatcher.utter_message("3) Electric")
        dispatcher.utter_message("4) Travel")
        return()
        
class ActionUploadRembursmentProofsValidate(Action):
# """ Complete Exit Process"""

    def name(self):
        return "action_Upload_Rembursment_Proofs_validate"

    def run(self, dispatcher, tracker, domain):
        serial = tracker.get_slot('phone_no')
        #print(serial)
        #print(type(serial))
        k=int(serial)
        #print("k is",k)
        if (k>4 or k==0):
            dispatcher.utter_message(template="utter_validateSlNO1")
            return [UserUtteranceReverted()]
        else:
            return()       

class ActionLeaveBalance(Action):


    def name(self):
        return "action_leave_balance"
    def run(self,dispatcher,tracker,domain):
    # serial = tracker.get_slot('Serial_Number')
        dispatcher.utter_message("Thank you for contacting us Mr. Thames")
        dispatcher.utter_message("Your available leave balance is ")
        serial1="1"
        date1= "Casual"
        time1= "9"
        serial2= "2"
        date2= "Medical"
        time2="2"
        serial3= "3"
        date3= "Paternity"
        time3="15"
        # dispatcher.utter_message("Based on your application information, we have following dates are available. Please select one on")
        out_message1=("{}) {} - {}.".format(serial1 ,date1, time1))
        out_message2=("{}) {} - {}.".format(serial2 ,date2, time2))
        out_message3=("{}) {} - {}.".format(serial3 ,date3, time3))
        dispatcher.utter_message(out_message1)
        dispatcher.utter_message(out_message2)
        dispatcher.utter_message(out_message3)            

class ActionCompanyUpdates(Action):


    def name(self):
        return "action_company_updates"
    def run(self,dispatcher,tracker,domain):
    # serial = tracker.get_slot('Serial_Number')
        dispatcher.utter_message("Company Updates:")
        dispatcher.utter_message("1) We have received most innovative 50 Deloitte Award 2020")
        dispatcher.utter_message("2) Voting links are open for Team Outing Venue")
        dispatcher.utter_message("3) Registrations open for Hackathon Sherwaters")
        dispatcher.utter_message("Select an update to see more info.")


class ActionMoreDetailUpdates(Action):
# """ This is for restarting the chat"""

    def name(self):
        return "action_more_detail_updates"
        
    def run(self,dispatcher,tracker,domain):
        choice=int(tracker.get_slot('phone_no'))
        if (choice>3 or choice==0):
            dispatcher.utter_message(template="Utter_validateSlNO1")
            return [UserUtteranceReverted()]
        else:   


            if(choice==1):
                dispatcher.utter_message("We have received most innovative 50 Deloitte Award 2020.")
                dispatcher.utter_message("The use of AI in the field of Healthcare to support the patients get the most appropriate health services must be acknowledged.")
                dispatcher.utter_message("more...")
                dispatcher.utter_message(template="utter_company_award")
            elif(choice==2):
                dispatcher.utter_message("Following are the places for team outings")
                dispatcher.utter_message("1) Wonderla Amusement Park, Bangalore")
                dispatcher.utter_message("2) Fun World Amusement Park,Bangalore")
                dispatcher.utter_message("3) Club Cabana Amusement Park, Bangalore")
                dispatcher.utter_message(template= "utter_mail")
                

            elif(choice==3):
                dispatcher.utter_message("The Hackathon Sherwaters is an exclusive opportunity to us to showcase our coding skills")
                dispatcher.utter_message("Languages Needed: Python")
                dispatcher.utter_message(template= "utter_nomination")
                
class ActionEmployeeBenefits(Action):


    def name(self):
        return "action_employee_benefits"
    def run(self,dispatcher,tracker,domain):
        dispatcher.utter_message("Here is a list of available Employee Benefits in our organization.")
        dispatcher.utter_message("1) Health Insurance")
        dispatcher.utter_message("2) Life Insurance")
        dispatcher.utter_message("3) Gratuity")
        dispatcher.utter_message("4) Stock Options")
        dispatcher.utter_message("Please select a option to see the detail.")


class ActionEmployeeBenefitsDetail(Action):
# """ This is for restarting the chat"""

    def name(self):
        return "action_employee_benefits_detail"
        
    def run(self,dispatcher,tracker,domain):
        choice=int(tracker.get_slot('phone_no'))
        if (choice>4 or choice==0):
            dispatcher.utter_message(template="Utter_validateSlNO1")
            return [UserUtteranceReverted()]
        else:   


            if(choice==1):
                dispatcher.utter_message("Every employee in the company is covered under a group health insurance policy from the date of joining till the date of employement termination.")
                dispatcher.utter_message("The Insurance amount varies for each employee and depends upon various factors like designation, selected Insurance band, personal contribution, etc.")
                dispatcher.utter_message("You can add your family members also, according to the plan")
                dispatcher.utter_message("Do you want the complete policy?")
                
               
            elif(choice==2):
                dispatcher.utter_message("Every employee in the company is covered under a group life insurance policy from the date of joining until the date of employment termination.")
                dispatcher.utter_message("The Insurance amount varies for each employee and depends upon various factors like designation, selected Insurance band, personal contribution, etc.")
                dispatcher.utter_message("Do you want the complete policy?")
                

            elif(choice==3):
                dispatcher.utter_message("Gratuity is given to all the employees for the services rendered by them during the period of employment. It is usually paid at the time of retirement but can be paid earlier, provided he/she completed 5 years with the organization.")
                dispatcher.utter_message("However it can be paid before if he/she meets certain requirements")
                dispatcher.utter_message("Do you want the complete policy?")
            else:
                dispatcher.utter_message("Employee stock options (ESOs) are a type of equity compensation granted by us to our employees and executives")
                dispatcher.utter_message("Rather than granting shares of stock directly, the company gives derivative options on the stock instead")
                dispatcher.utter_message("These options come in the form of regular call options and give the employee the right to buy the company's stock at a specified price for a finite period")
                dispatcher.utter_message("Terms of ESOs will be fully spelt out for an employee in an employee stock options agreement.")
                dispatcher.utter_message("Do you want the complete policy?")

class ActionPoicyOverMail(Action):


    def name(self):
        return "action_policy_over_mail"
    def run(self,dispatcher,tracker,domain):
        choice=int(tracker.get_slot('phone_no'))
        if choice==2:
            dispatcher.utter_message(template = "utter_life_insurance_overmail")
            dispatcher.utter_message("Would you like me to send it to your official email too?")
        elif choice == 1:
            dispatcher.utter_message(template = "utter_health_insurance_overmail")
            dispatcher.utter_message("Would you like me to send it to your official email too?")
        elif choice == 3:
            dispatcher.utter_message(template = "utter_Gratuity_details_overmail")
            dispatcher.utter_message("Would you like me to send it to your official email too?")
        else:
            dispatcher.utter_message(template = "utter_ESO_overmail")
            dispatcher.utter_message("Would you like me to send it to your official email too?")
   

class Getsalaryslip(Action):
    """Business Email Extractions"""
    

    def name(self):
        return "action_get_salary_slip"
    
    def run(self,dispatcher,tracker,domain):

        dispatcher.utter_message(template = "utter_salary_slip_link")
        return() 
        
class ActionGrievnceReportAndManagementIdentityValidate(Action):
# """ This is for restarting the chat"""

    def name(self):
        return "action_grievance_reporting_and_management_identity_validate"
        
    def run(self,dispatcher,tracker,domain):
        #report = tracker.get_slot('quickreply_value27')
        serial = tracker.get_slot('phone_no')
        k = int(serial)

        if (k>6 or k==0):
            dispatcher.utter_message(template="Utter_validateSlNO1")
            return [UserUtteranceReverted()]
        if(k==1):
            dispatcher.utter_message("Lost card on 28-Sep-20")
            dispatcher.utter_message("Lost identity card on 28-sep-20. Your request is registered. An email describing the procedure to apply for lost identity card is sent to your official email ID.")
        elif(k==2):
            dispatcher.utter_message("Lost card on 27-Sep-20")
            dispatcher.utter_message("Lost identity card on 27-sep-20. Your request is registered. An email describing the procedure to apply for lost identity card is sent to your official email ID.")
        elif(k==3):
            dispatcher.utter_message("Lost card on 26-Sep-20")
            dispatcher.utter_message("Lost identity card on 26-sep-20. Your request is registered. An email describing the procedure to apply for lost identity card is sent to your official email ID.")
        elif(k==4):
            dispatcher.utter_message("Lost card on 25-Sep-20")
            dispatcher.utter_message("Lost identity card on 25-sep-20. Your request is registered. An email describing the procedure to apply for lost identity card is sent to your official email ID.")
        elif(k==5):
            dispatcher.utter_message("Lost card on 24-Sep-20")
            dispatcher.utter_message("Lost identity card on 24-sep-20. Your request is registered. An email describing the procedure to apply for lost identity card is sent to your official email ID.")
        else:
            dispatcher.utter_message("Earlier")
            dispatcher.utter_message("Lost identity card earlier. Your request is registered. An email describing the procedure to apply for lost identity card is sent to your official email ID.")



class ActionGrievnceReportAndManagementAccessValidate(Action):
# """ This is for restarting the chat"""

    def name(self):
        return "action_grievance_reporting_and_management_access_validate"
        
    def run(self,dispatcher,tracker,domain):
        #report = tracker.get_slot('quickreply_value27')
        serial = tracker.get_slot('phone_no')
        k = int(serial)

        if (k>6 or k==0):
            dispatcher.utter_message(template="Utter_validateSlNO1")
            return [UserUtteranceReverted()]
        if(k==1):
            dispatcher.utter_message("Lost card on 28-Sep-20")
            dispatcher.utter_message("Lost Access card on 28-sep-20. Your request is registered. An email describing the procedure to apply for lost Access card is sent to your official email ID.")
        elif(k==2):
            dispatcher.utter_message("Lost card on 27-Sep-20")
            dispatcher.utter_message("Lost Access card on 27-sep-20. Your request is registered. An email describing the procedure to apply for lost Access card is sent to your official email ID.")
        elif(k==3):
            dispatcher.utter_message("Lost card on 26-Sep-20")
            dispatcher.utter_message("Lost Access card on 26-sep-20. Your request is registered. An email describing the procedure to apply for lost Access card is sent to your official email ID.")
        elif(k==4):
            dispatcher.utter_message("Lost card on 25-Sep-20")
            dispatcher.utter_message("Lost Access card on 25-sep-20. Your request is registered. An email describing the procedure to apply for lost Access card is sent to your official email ID.")
        elif(k==5):
            dispatcher.utter_message("Lost card on 24-Sep-20")
            dispatcher.utter_message("Lost Access card on 24-sep-20. Your request is registered. An email describing the procedure to apply for lost Access card is sent to your official email ID.")
        else:
            dispatcher.utter_message("Earlier")
            dispatcher.utter_message("Lost Access card earlier. Your request is registered. An email describing the procedure to apply for lost Access card is sent to your official email ID.")



class ActionOtherComplaint(Action):
# """ This is for other complaint"""

    def name(self):
        return "action_other_complaint"

    def run(self, dispatcher, tracker, domain):
        #dispatcher.utter_message("Type other complaint")
        message = tracker.latest_message.get('text')
        print(message)
        return [SlotSet('custom_messege', message)]
        
class ActionDateValidate(Action):
    """Enter the serial  Extractions"""
    
    def name(self):
        return "action_date_validate"
    def run(self,dispatcher,tracker,domain): 
        # serial = tracker.get_slot('Serial_Number')
        serial1="1"
        date1= "28-Sep-20"
  
        serial2= "2"
        date2= "27-Sep-20"
    
        serial3= "3"
        date3= "26-Sep-20"
    
        serial4= "4"
        date4= "25-Sep20"
    
        serial5= "5"
        date5= "24-Sep-20"
    
        out_message1=("{}) {}.".format(serial1 ,date1))
        out_message2=("{}) {}.".format(serial2 ,date2))
        out_message3=("{}) {}.".format(serial3 ,date3))
        out_message4=("{}) {}.".format(serial4 ,date4))
        out_message5=("{}) {}.".format(serial5 ,date5))
        
        dispatcher.utter_message(out_message1)
        dispatcher.utter_message(out_message2)
        dispatcher.utter_message(out_message3)
        dispatcher.utter_message(out_message4)  
        dispatcher.utter_message(out_message5)
        dispatcher.utter_message("6) Earlier")