## welcome message + Recruitment + Interview_Scheduling + deny + any_thing_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Interview_Scheduling"}
   - slot{"quickreply_value1":"Interview_Scheduling"}
   - utter_Interview_message
   - action_validate
* Number{"phone_no":"1"}
   - slot{"phone_no":"1"}
   - action_serial_number
* quickreply8{"quickreply_value8":"deny"}
   - slot{"quickreply_value8":"deny"}
   - utter_anything_else
*quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + Interview_Scheduling + deny + any_thing_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Interview_Scheduling"}
   - slot{"quickreply_value1":"Interview_Scheduling"}
   - utter_Interview_message
   - action_validate
* Number{"phone_no":"1"}
   - slot{"phone_no":"1"}
   - action_serial_number
* quickreply8{"quickreply_value8":"deny"}
   - slot{"quickreply_value8":"deny"}
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"}  
   - utter_thankyou_feedback
   - action_restart
   


## welcome message + Recruitment + Interview_Scheduling + affirm + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Interview_Scheduling"}
   - slot{"quickreply_value1":"Interview_Scheduling"}
   - utter_Interview_message
   - action_validate
* Number{"phone_no":"1"}
   - slot{"phone_no":"1"}
   - action_serial_number
* quickreply8{"quickreply_value8":"affirm"}
   - slot{"quickreply_value8":"affirm"}
   - utter_wish_message
   - utter_anything_else
*quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + Interview_Scheduling + affirm + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Interview_Scheduling"}
   - slot{"quickreply_value1":"Interview_Scheduling"}
   - utter_Interview_message
   - action_validate
* Number{"phone_no":"1"}
   - slot{"phone_no":"1"}
   - action_serial_number
* quickreply8{"quickreply_value8":"affirm"}
   - slot{"quickreply_value8":"affirm"}
   - utter_wish_message
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + feedback
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Candidate_feedback"}
   - slot{"quickreply_value1":"Candidate_feedback"}
   - utter_feedback_mes
   - utter_feedback_main
* quickreply9{"quickreply_value9":"phone_no"}
   - slot{"quickreply_value9":"phone_no"}
   - action_feedback
   - action_restart
   
## welcome message + Recruitment + screening + anythingelseYes
* greet
    - utter_welcome_message
* Number{"phone_no":"9502245747"}
    - slot{"phone_no":"9502245747"}
    - action_phoneNumber
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"Recruitment"}
    - slot{"quickreply_value":"Recruitment"}
    - utter_recruitment
* quickreply1{"quickreply_value1":"screening"}
    - slot{"quickreply_value1":"screening"}
    - utter_ctc
* quickreply7{"quickreply_value7":"salary"}
    - slot{"quickreply_value7":"salary"}
    - utter_Exp_ctc
* quickreply5{"quickreply_value5":"salary"}
    - slot{"quickreply_value5":"salary"}
    - utter_Notice_period
* quickreply6{"quickreply_value6":"notice_period"}
    - slot{"quickreply_value6":"notice_period"}
    - utter_thankyou_for_details
    - utter_anything_else
*quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + screening + anythingelse_NO
* greet
    - utter_welcome_message
* Number{"phone_no":"9502245747"}
    - slot{"phone_no":"9502245747"}
    - action_phoneNumber
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"Recruitment"}
    - slot{"quickreply_value":"Recruitment"}
    - utter_recruitment
* quickreply1{"quickreply_value1":"screening"}
    - slot{"quickreply_value1":"screening"}
    - utter_ctc
* quickreply7{"quickreply_value7":"salary"}
    - slot{"quickreply_value7":"salary"}
    - utter_Exp_ctc
* quickreply5{"quickreply_value5":"salary"}
    - slot{"quickreply_value5":"salary"}
    - utter_Notice_period
* quickreply6{"quickreply_value6":"notice_period"}
    - slot{"quickreply_value6":"notice_period"}
    - utter_thankyou_for_details
    - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + application_status + anything_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Application_Status"}
   - slot{"quickreply_value1":"Application_Status"}
   - actions_application_status
   - utter_anything_else
*quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + application_status + anything_No
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Application_Status"}
   - slot{"quickreply_value1":"Application_Status"}
   - actions_application_status
   - utter_anything_else   
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment+candidate assesment +any_thing_yes

* greet
    - utter_welcome_message
* Number{"phone_no":"8792208625"}
    - slot{"phone_no":"8792208625"}
    - action_phoneNumber
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"Recruitment"}
    - slot{"quickreply_value":"Recruitment"}
    - utter_recruitment
* quickreply1{"quickreply_value1":"Candidate_Assessment_Test"}
    - slot{"quickreply_value1":"Candidate_Assessment_Test"}
    - action_candidate_assesment
    - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment+candidate assesment +any_thing_No

* greet
    - utter_welcome_message
* Number{"phone_no":"8792208625"}
    - slot{"phone_no":"8792208625"}
    - action_phoneNumber
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"Recruitment"}
    - slot{"quickreply_value":"Recruitment"}
    - utter_recruitment
* quickreply1{"quickreply_value1":"Candidate_Assessment_Test"}
    - slot{"quickreply_value1":"Candidate_Assessment_Test"}
    - action_candidate_assesment
    - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart


## welcome message + Recruitment + job_Opening + PHP + affirm + any_thing_yes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"PHP"}
  - slot{"quickreply_value4":"PHP"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "quickreply_value2ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
   
## welcome message + Recruitment + job_Opening + PHP + affirm + any_thing_No

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"PHP"}
  - slot{"quickreply_value4":"PHP"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "quickreply_value2ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart


## welcome message + Recruitment + job_Opening + PHP + deny + any_thing_yes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"PHP"}
  - slot{"quickreply_value4":"PHP"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"}
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + job_Opening + PHP + deny + any_thing_No

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"PHP"}
  - slot{"quickreply_value4":"PHP"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"}
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + job_Opening + Python + affirm +any_thing_yes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"Python"}
  - slot{"quickreply_value4":"Python"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart


## welcome message + Recruitment + job_Opening + Python + affirm +any_thing_No

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"Python"}
  - slot{"quickreply_value4":"Python"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + job_Opening + Python + deny + any_thing_yes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"Python"}
  - slot{"quickreply_value4":"Python"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"}
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + job_Opening + Python + deny + any_thing_No

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"Python"}
  - slot{"quickreply_value4":"Python"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"}
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + job_Opening + UI/UX + affirm + anything_else_yes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"UI/UX"}
  - slot{"quickreply_value4":"UI/UX"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + job_Opening + UI/UX + affirm + anything_else_No

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"UI/UX"}
  - slot{"quickreply_value4":"UI/UX"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + job_Opening + UI/UX + deny +anything_else_yes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"UI/UX"}
  - slot{"quickreply_value4":"UI/UX"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"} 
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + job_Opening + UI/UX + deny +anything_else_No

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"UI/UX"}
  - slot{"quickreply_value4":"UI/UX"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"} 
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + job_Opening + QA/Testing + affirm + anything_elseYes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"QA/Testing"}
  - slot{"quickreply_value4":"QA/Testing"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + job_Opening + QA/Testing + affirm + anything_elseNo

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"QA/Testing"}
  - slot{"quickreply_value4":"QA/Testing"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"affirm"}
  - slot{"quickreply_value2":"affirm"}
  - utter_person_name
* name{"person_name": "preetham"}
  - slot{"person_name":"preetham"}
  - utter_business_email
* email{"business_email": "ppreetham0@gmail.com"}
  - slot{"business_email":"ppreetham0@gmail.com"}
  - action_business_email
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou_application
  - utter_contact
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + job_Opening + QA/Testing + deny + anything_elseYes

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"QA/Testing"}
  - slot{"quickreply_value4":"QA/Testing"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"}
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + Recruitment + job_Opening + QA/Testing + deny + anything_elseNo

* get_started
  - utter_welcome_message
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - action_phoneNumber
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"Recruitment"}
  - slot{"quickreply_value":"Recruitment"}
  - utter_recruitment
* quickreply1{"quickreply_value1":"job_Opening"}
  - slot{"quickreply_value1":"job_Opening"}
  - utter_available_job
* quickreply4{"quickreply_value4":"QA/Testing"}
  - slot{"quickreply_value4":"QA/Testing"}
  - action_job_opening
* Number{"phone_no": "123"}
  - slot{"phone_no": "123"}
  - action_select_job_position
* quickreply2{"quickreply_value2":"deny"}
  - slot{"quickreply_value2":"deny"}
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Recruitment + Employee_Onboarding + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Employee_onboarding"}
   - slot{"quickreply_value1":"Employee_onboarding"}
   - utter_aadhaar_number
* Number{"phone_no":"1128-3344-5060"}
   - slot{"phone_no":"1128-3344-5060"}
   - action_aadher_card
* Number{"phone_no":"YZSMQ3143M"}
   - slot{"phone_no":"YZSMQ3143M"}
   - action_Pan_number
* Number{"phone_no":"PF/TOW/5133464/477/8911813"}
   - slot{"phone_no":"PF/TOW/5133464/477/8911813"}
   - action_Pf_number
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + Recruitment + Employee_Onboarding + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Recruitment"}
   - slot{"quickreply_value":"Recruitment"}
   - utter_recruitment
* quickreply1{"quickreply_value1":"Employee_onboarding"}
   - slot{"quickreply_value1":"Employee_onboarding"}
   - utter_aadhaar_number
* Number{"phone_no":"1128-3344-5060"}
   - slot{"phone_no":"1128-3344-5060"}
   - action_aadher_card
* Number{"phone_no":"YZSMQ3143M"}
   - slot{"phone_no":"YZSMQ3143M"}
   - action_Pan_number
* Number{"phone_no":"PF/TOW/5133464/477/8911813"}
   - slot{"phone_no":"PF/TOW/5133464/477/8911813"}
   - action_Pf_number
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Medical_Officer + Get_job_description +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Medical_Officer"}
   - slot{"quickreply_value21":"Medical_Officer"}
   - utter_medical_officer
* quickreply22{"quickreply_value22":"Get_job_description"}
   - slot{"quickreply_value22":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Medical_Officer + Get_job_description +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Medical_Officer"}
   - slot{"quickreply_value21":"Medical_Officer"}
   - utter_medical_officer
* quickreply22{"quickreply_value22":"Get_job_description"}
   - slot{"quickreply_value22":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Medical_Officer + Apply_for_job +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Medical_Officer"}
   - slot{"quickreply_value21":"Medical_Officer"}
   - utter_medical_officer
* quickreply22{"quickreply_value22":"Apply_for_job"}
   - slot{"quickreply_value22":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Medical_Officer + Apply_for_job +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Medical_Officer"}
   - slot{"quickreply_value21":"Medical_Officer"}
   - utter_medical_officer
* quickreply22{"quickreply_value22":"Apply_for_job"}
   - slot{"quickreply_value22":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Medical_Officer + Get_Referral_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Medical_Officer"}
   - slot{"quickreply_value21":"Medical_Officer"}
   - utter_medical_officer
* quickreply22{"quickreply_value22":"Get_Referral_link"}
   - slot{"quickreply_value22":"Get_Referral_link"}
   - action_internal_job_Postings
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Medical_Officer + Get_Referral_link +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Medical_Officer"}
   - slot{"quickreply_value21":"Medical_Officer"}
   - utter_medical_officer
* quickreply22{"quickreply_value22":"Get_Referral_link"}
   - slot{"quickreply_value22":"Get_Referral_link"}
   - action_internal_job_Postings
  - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   

## welcome message + HR_Support + Internal_Job_Postings + Network_Manager + Get_job_description+ anythingelseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Network_Manager"}
   - slot{"quickreply_value21":"Network_Manager"}
   - utter_Network_Manager
* quickreply23{"quickreply_value23":"Get_job_description"}
   - slot{"quickreply_value23":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Network_Manager + Get_job_description+ anythingelseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Network_Manager"}
   - slot{"quickreply_value21":"Network_Manager"}
   - utter_Network_Manager
* quickreply23{"quickreply_value23":"Get_job_description"}
   - slot{"quickreply_value23":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR_Support + Internal_Job_Postings + Network_Manager + Apply_for_job + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Network_Manager"}
   - slot{"quickreply_value21":"Network_Manager"}
   - utter_Network_Manager
* quickreply23{"quickreply_value23":"Apply_for_job"}
   - slot{"quickreply_value23":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Network_Manager + Apply_for_job + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Network_Manager"}
   - slot{"quickreply_value21":"Network_Manager"}
   - utter_Network_Manager
* quickreply23{"quickreply_value23":"Apply_for_job"}
   - slot{"quickreply_value23":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Network_Manager + Get_Referral_link + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Network_Manager"}
   - slot{"quickreply_value21":"Network_Manager"}
   - utter_Network_Manager
* quickreply23{"quickreply_value23":"Get_Referral_link"}
   - slot{"quickreply_value23":"Get_Referral_link"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Network_Manager + Get_Referral_link + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Network_Manager"}
   - slot{"quickreply_value21":"Network_Manager"}
   - utter_Network_Manager
* quickreply23{"quickreply_value23":"Get_Referral_link"}
   - slot{"quickreply_value23":"Get_Referral_link"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
   
   
## welcome message + HR_Support + Internal_Job_Postings + Data_Scientist + Get_job_description anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Data_Scientist"}
   - slot{"quickreply_value21":"Data_Scientist"}
   - utter_Data_Scientist
* quickreply24{"quickreply_value24":"Get_job_description"}
   - slot{"quickreply_value24":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Data_Scientist + Get_job_description anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Data_Scientist"}
   - slot{"quickreply_value21":"Data_Scientist"}
   - utter_Data_Scientist
* quickreply24{"quickreply_value24":"Get_job_description"}
   - slot{"quickreply_value24":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR_Support + Internal_Job_Postings + Data_Scientist + Apply_for_job + anythingelseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Data_Scientist"}
   - slot{"quickreply_value21":"Data_Scientist"}
   - utter_Data_Scientist
* quickreply24{"quickreply_value24":"Apply_for_job"}
   - slot{"quickreply_value24":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Data_Scientist + Apply_for_job + anythingelseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Data_Scientist"}
   - slot{"quickreply_value21":"Data_Scientist"}
   - utter_Data_Scientist
* quickreply24{"quickreply_value24":"Apply_for_job"}
   - slot{"quickreply_value24":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
*quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Data_Scientist + Get_Referral_link + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Data_Scientist"}
   - slot{"quickreply_value21":"Data_Scientist"}
   - utter_Data_Scientist
* quickreply24{"quickreply_value24":"Get_Referral_link"}
   - slot{"quickreply_value24":"Get_Referral_link"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart  
   
## welcome message + HR_Support + Internal_Job_Postings + Data_Scientist + Get_Referral_link + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Data_Scientist"}
   - slot{"quickreply_value21":"Data_Scientist"}
   - utter_Data_Scientist
* quickreply24{"quickreply_value24":"Get_Referral_link"}
   - slot{"quickreply_value24":"Get_Referral_link"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Jr.DevOps + Get_job_description +aythingYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Jr.DevOps"}
   - slot{"quickreply_value21":"Jr.DevOps"}
   - utter_Jr.DevOps
* quickreply25{"quickreply_value25":"Get_job_description"}
   - slot{"quickreply_value25":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + HR_Support + Internal_Job_Postings + Jr.DevOps + Get_job_description +aythingNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Jr.DevOps"}
   - slot{"quickreply_value21":"Jr.DevOps"}
   - utter_Jr.DevOps
* quickreply25{"quickreply_value25":"Get_job_description"}
   - slot{"quickreply_value25":"Get_job_description"}
   - action_internal_job_Postings
   - utter_anything_else   
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR_Support + Internal_Job_Postings + Jr.DevOps + Apply_for_job + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Jr.DevOps"}
   - slot{"quickreply_value21":"Jr.DevOps"}
   - utter_Jr.DevOps
* quickreply25{"quickreply_value25":"Apply_for_job"}
   - slot{"quickreply_value25":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Jr.DevOps + Apply_for_job + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Jr.DevOps"}
   - slot{"quickreply_value21":"Jr.DevOps"}
   - utter_Jr.DevOps
* quickreply25{"quickreply_value25":"Apply_for_job"}
   - slot{"quickreply_value25":"Apply_for_job"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support + Internal_Job_Postings + Jr.DevOps + Get_Referral_link + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Jr.DevOps"}
   - slot{"quickreply_value21":"Jr.DevOps"}
   - utter_Jr.DevOps
* quickreply25{"quickreply_value25":"Get_Referral_link"}
   - slot{"quickreply_value25":"Get_Referral_link"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart  
   
## welcome message + HR_Support + Internal_Job_Postings + Jr.DevOps + Get_Referral_link + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - action_phoneNumber  
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Internal_Job_Postings"}
   - slot{"quickreply_value10":"Internal_Job_Postings"}
   - utter_current_jon_openings
* quickreply21{"quickreply_value21":"Jr.DevOps"}
   - slot{"quickreply_value21":"Jr.DevOps"}
   - utter_Jr.DevOps
* quickreply25{"quickreply_value25":"Get_Referral_link"}
   - slot{"quickreply_value25":"Get_Referral_link"}
   - action_internal_job_Postings
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + HR_Support+ Check_leave_balance + anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Check_leave_balance"}
   - slot{"quickreply_value10":"Check_leave_balance"}
   - action_leave_balance
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + HR_Support+ Check_leave_balance + anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Check_leave_balance"}
   - slot{"quickreply_value10":"Check_leave_balance"}
   - action_leave_balance
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR_Support+ Apply_for_leave + anything_else_yes
* greet
    - utter_welcome_message
    
* Number{"phone_no":"9502245747"}
    - slot{"phone_no":"9502245747"}
    - utter_otp
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"HR_Support"}
    - slot{"quickreply_value":"HR_Support"}
    - utter_hr_support
* quickreply10{"quickreply_value10":"Apply_for_Leave"}
    - slot{"quickreply_value10":"Apply_for_Leave"}
    - utter_apply_leave
* Number{"phone_no":"1"}
    - slot{"phone_no":"1"}
    - utter_provide_dates
* date{"date":"05/02/2020"}
    - slot{"date":"05/02/2020"}
    - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + HR_Support+ Apply_for_leave + anything_else_no
* greet
    - utter_welcome_message
* Number{"phone_no":"9502245747"}
    - slot{"phone_no":"9502245747"}
    - utter_otp
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"HR_Support"}
    - slot{"quickreply_value":"HR_Support"}
    - utter_hr_support
* quickreply10{"quickreply_value10":"Apply_for_Leave"}
    - slot{"quickreply_value10":"Apply_for_Leave"}
    - utter_apply_leave
* Number{"phone_no":"1"}
    - slot{"phone_no":"1"}
    - utter_provide_dates
* date{"date":"05/02/2020"}
    - slot{"date":"05/02/2020"}
    - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR Support + Upload Rembursment Proofs + anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Upload_Rembursment_Proofs"}
   - slot{"quickreply_value10":"Upload_Rembursment_Proofs"}
   - action_Upload_Rembursment_Proofs
* Number{"phone_no": "1"}
   - slot{"phone_no": "1"}
   - action_Upload_Rembursment_Proofs_validate
   - utter_soft_copy_bill
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + HR Support + Upload Rembursment Proofs + anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Upload_Rembursment_Proofs"}
   - slot{"quickreply_value10":"Upload_Rembursment_Proofs"}
   - action_Upload_Rembursment_Proofs
* Number{"phone_no": "1"}
   - slot{"phone_no": "1"}
   - action_Upload_Rembursment_Proofs_validate
   - utter_soft_copy_bill
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR Support + Get_Salary_Slip + anything_else_yes

* greet
    - utter_welcome_message
* Number{"phone_no":"9502245747"}
    - slot{"phone_no":"9502245747"}
    - utter_otp
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"HR_Support"}
    - slot{"quickreply_value":"HR_Support"}
    - utter_hr_support
* quickreply10{"quickreply_value10":"Get_Salary_slip"}
    - slot{"quickreply_value10":"Get_Salary_slip"}
    - utter_salary_slip
* date{"date":"05/02/2020"}
    - slot{"date":"05/02/2020"}
	- action_get_salary_slip
    - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart


## welcome message + HR Support + Get_Salary_Slip + anything_else_no

* greet
    - utter_welcome_message
* Number{"phone_no":"9502245747"}
    - slot{"phone_no":"9502245747"}
    - utter_otp
* Number{"phone_no":"123456"}
    - slot{"phone_no":"123456"}
    - utter_thankyou
    - utter_main
* quickreply{"quickreply_value":"HR_Support"}
    - slot{"quickreply_value":"HR_Support"}
    - utter_hr_support
* quickreply10{"quickreply_value10":"Get_Salary_slip"}
    - slot{"quickreply_value10":"Get_Salary_slip"}
    - utter_salary_slip
* date{"date":"05/02/2020"}
    - slot{"date":"05/02/2020"}
	- action_get_salary_slip
    - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR_Support + Get_Policy_Details + anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Get_Policy_Details"}
   - slot{"quickreply_value10":"Get_Policy_Details"}
   - action_policy_validate
   - utter_policy_select_which
* Number{"phone_no": "5"}
   - slot{"phone_no": "5"}
   - action_policy_number
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + HR_Support + Get_Policy_Details  +anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Get_Policy_Details"}
   - slot{"quickreply_value10":"Get_Policy_Details"}
   - action_policy_validate
   - utter_policy_select_which
* Number{"phone_no": "5"}
   - slot{"phone_no": "5"}
   - action_policy_number
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + HR_support + Frequent_Employee_Satisfaction_Survery_and_Ratings 
  - utter_welcome_message
  
* Number{"phone_no": "8792208625"}
  - slot{"phone_no": "8792208625"}
  - utter_otp
* Number{"phone_no": "123456"}
  - slot{"phone_no": "123456"}
  - utter_thankyou
  - utter_main
* quickreply{"quickreply_value":"HR_Support"}
  - slot{"quickreply_value":"HR_Support"}
  - utter_hr_support
* quickreply10{"quickreply_value10":"Frequent_Employee_Satisfaction_Survery_and_Ratings"}
  - slot{"quickreply_value10":"Frequent_Employee_Satisfaction_Survery_and_Ratings"}
  - utter_feedback_ Employee
  - utter_communication
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
  - slot{"quickreply_value3":"Number"} 
  - utter_Policies
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
  - slot{"quickreply_value3":"Number"} 
  - utter_Employee Benefits
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
  - slot{"quickreply_value3":"Number"} 
  - utter_Recognition
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
  - slot{"quickreply_value3":"Number"} 
  - action_feedback
  - action_restart
   
## welcome message + HR Support + Complete_exit_process+ anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Complete_Exit_Process"}
   - slot{"quickreply_value10":"Complete_Exit_Process"}
   - action_complete_exit_process
    - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
   - slot{"quickreply_value50":"affirm"}
   - action_restart

## welcome message + HR Support + Complete_exit_process+ anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"HR_Support"}
   - slot{"quickreply_value":"HR_Support"}
   - utter_hr_support
* quickreply10{"quickreply_value10":"Complete_Exit_Process"}
   - slot{"quickreply_value10":"Complete_Exit_Process"}
   - action_complete_exit_process
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Engagement+Company_Updates+ anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"company_updates"}
   - slot{"quickreply_value12":"company_updates"}
   - action_company_updates
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_more_detail_updates
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement+Company_Updates+ anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"company_updates"}
   - slot{"quickreply_value12":"company_updates"}
   - action_company_updates
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_more_detail_updates
  - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement + employee_benefits + benfits_detail_yes + lic_policy_over_mail_yes + anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"employee_benefits"}
   - slot{"quickreply_value12":"employee_benefits"}
   - action_employee_benefits
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_employee_benefits_detail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"affirm"}
  - slot{"quickreply_value13":"affirm"}
  - action_policy_over_mail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"affirm"}
  - slot{"quickreply_value13":"affirm"}
  - utter_policy_mail
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + employee_benefits + benfits_detail_yes + lic_policy_over_mail_yes + anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"employee_benefits"}
   - slot{"quickreply_value12":"employee_benefits"}
   - action_employee_benefits
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_employee_benefits_detail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"affirm"}
  - slot{"quickreply_value13":"affirm"}
  - action_policy_over_mail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"affirm"}
  - slot{"quickreply_value13":"affirm"}
  - utter_policy_mail
  - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart


## welcome message + Engagement + employee_benefits + benfits_detail_yes + lic_policy_over_mail_no + anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"employee_benefits"}
   - slot{"quickreply_value12":"employee_benefits"}
   - action_employee_benefits
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_employee_benefits_detail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"affirm"}
  - slot{"quickreply_value13":"affirm"}
  - action_policy_over_mail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"deny"}
  - slot{"quickreply_value13":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + employee_benefits + benfits_detail_yes + lic_policy_over_mail_no + anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"employee_benefits"}
   - slot{"quickreply_value12":"employee_benefits"}
   - action_employee_benefits
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_employee_benefits_detail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"affirm"}
  - slot{"quickreply_value13":"affirm"}
  - action_policy_over_mail
  - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart


## welcome message + Engagement + employee_benefits + benfits_detail_no + anything_else_yes:
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"employee_benefits"}
   - slot{"quickreply_value12":"employee_benefits"}
   - action_employee_benefits
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_employee_benefits_detail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"deny"}
  - slot{"quickreply_value13":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + employee_benefits + benfits_detail_no + anything_else_no:
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"employee_benefits"}
   - slot{"quickreply_value12":"employee_benefits"}
   - action_employee_benefits
* Number{"phone_no": "1"}
  - slot{"phone_no": "1"}
  - action_employee_benefits_detail
  - utter_options_yesno
* quickreply13{"quickreply_value13":"deny"}
  - slot{"quickreply_value13":"deny"}
  - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart






## welcome message + Engagement + learning_and_training +  Neogitation _course +Beginner_Neogitation_course + course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Beginner_Neogitation_course"}
   - slot{"quickreply_value33":"Beginner_Neogitation_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
  
## welcome message + Engagement + learning_and_training +  Neogitation _course +Beginner_Neogitation_course + course_link +anything_elseno
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Beginner_Neogitation_course"}
   - slot{"quickreply_value33":"Beginner_Neogitation_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart
   
## welcome message + Engagement + learning_and_training+  Neogitation _course +Intermediate_Neogitation_course + course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Intermediate_Neogitation_course"}
   - slot{"quickreply_value33":"Intermediate_Neogitation_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement + learning_and_training+  Neogitation _course +Intermediate_Neogitation_course + course_link +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Intermediate_Neogitation_course"}
   - slot{"quickreply_value33":"Intermediate_Neogitation_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement + learning_and_training+  Neogitation _course +Fasttrack_course + course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Fasttrack_course"}
   - slot{"quickreply_value33":"Fasttrack_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement + learning_and_training+  Neogitation _course +Fasttrack_course + course_link +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Fasttrack_course"}
   - slot{"quickreply_value33":"Fasttrack_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart


## welcome message + Engagement + learning_and_training+  Neogitation _course +Advanced_course + course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Advanced_course"}
   - slot{"quickreply_value33":"Advanced_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement + learning_and_training+  Neogitation _course +Advanced_course + course_link +anything_elseNo
* get_started
   - utter_welcome_message   
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Neogitation_skills"}
   - slot{"quickreply_value31":"Neogitation_skills"}
   - utter_Learning_neogitation
* quickreply33{"quickreply_value33":"Advanced_course"}
   - slot{"quickreply_value33":"Advanced_course"}
   - utter_training_Neogitation
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement +  learning_and_training + Managerial_course + Beginner_Managerial_course + course_link + anythingelse_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Beginner_Managerial_course"}
   - slot{"quickreply_value34":"Beginner_Managerial_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement +  learning_and_training + Managerial_course + Beginner_Managerial_course + course_link + anythingelse_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Beginner_Managerial_course"}
   - slot{"quickreply_value34":"Beginner_Managerial_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement +  learning_and_training + Managerial_course + Beginner_Managerial_course + course_link _ anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Intermediate_Managerial_course"}
   - slot{"quickreply_value34":"Intermediate_Managerial_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement +  learning_and_training + Managerial_course + Beginner_Managerial_course + course_link _ anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Intermediate_Managerial_course"}
   - slot{"quickreply_value34":"Intermediate_Managerial_course"}
   - utter_training_Managerial
   - utter_anything_else
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement +  learning_and_training + Managerial_course + Advanced_course + course_link+anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Advanced_course"}
   - slot{"quickreply_value34":"Advanced_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart


## welcome message + Engagement +  learning_and_training + Managerial_course + Advanced_course + course_link+anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Advanced_course"}
   - slot{"quickreply_value34":"Advanced_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart
  
## welcome message + Engagement +  learning_and_training + Managerial_course + Fasttrack_course + course_link + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Fasttrack_course"}
   - slot{"quickreply_value34":"Fasttrack_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
  
## welcome message + Engagement +  learning_and_training + Managerial_course + Fasttrack_course + course_link + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Managerial_skills"}
   - slot{"quickreply_value31":"Managerial_skills"}
   - utter_Learning_Managerial
* quickreply34{"quickreply_value34":"Fasttrack_course"}
   - slot{"quickreply_value34":"Fasttrack_course"}
   - utter_training_Managerial
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart
  
## welcome message + Engagement +  learning_and_training + Medical_course + Beginner_Medical_course +course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Beginner_Medical_course"}
   - slot{"quickreply_value35":"Beginner_Medical_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement +  learning_and_training + Medical_course + Beginner_Medical_course +course_link +anything_elseno
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Beginner_Medical_course"}
   - slot{"quickreply_value35":"Beginner_Medical_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement +  learning_and_training + Medical_course + Intermediate_Medical_course +course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Intermediate_Medical_course"}
   - slot{"quickreply_value35":"Intermediate_Medical_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement +  learning_and_training + Medical_course + Intermediate_Medical_course +course_link +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Intermediate_Medical_course"}
   - slot{"quickreply_value35":"Intermediate_Medical_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart


## welcome message + Engagement +  learning_and_training + Medical_course + Advanced_course +course_link + anything_elseyes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Advanced_course"}
   - slot{"quickreply_value35":"Advanced_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart


## welcome message + Engagement +  learning_and_training + Medical_course + Advanced_course +course_link + anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Advanced_course"}
   - slot{"quickreply_value35":"Advanced_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement +  learning_and_training + Medical_course + Fasttrack_course +course_link +anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Fasttrack_course"}
   - slot{"quickreply_value35":"Fasttrack_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
  
## welcome message + Engagement +  learning_and_training + Medical_course + Fasttrack_course +course_link +anything_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Medical_aid"}
   - slot{"quickreply_value31":"Medical_aid"}
   - utter_Learning_Medical
* quickreply35{"quickreply_value35":"Fasttrack_course"}
   - slot{"quickreply_value35":"Fasttrack_course"}
   - utter_training_medical
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
  - slot{"quickreply_value50":"deny"}
  - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
  - utter_thankyou_feedback
  - action_restart

## welcome message + Engagement + learning_and_training +communication+Beginner_Communication_course+ course_link+anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Beginner_Communication_course"}
   - slot{"quickreply_value32":"Beginner_Communication_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training +communication+Beginner_Communication_course+ course_link+anything_else_no:
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Beginner_Communication_course"}
   - slot{"quickreply_value32":"Beginner_Communication_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Engagement + learning_and_training +communication+Intermediate_Communication_course+ course_link+anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Intermediate_Communication_course"}
   - slot{"quickreply_value32":"Intermediate_Communication_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training +communication+Intermediate_Communication_course+ course_link+anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Intermediate_Communication_course"}
   - slot{"quickreply_value32":"Intermediate_Communication_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Engagement + learning_and_training +communication+ Fasttrack_course+ course_link+anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Fasttrack_course"}
   - slot{"quickreply_value32":"Fasttrack_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training +communication+ Fasttrack_course+ course_link+anything_else_no:
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Fasttrack_course"}
   - slot{"quickreply_value32":"Fasttrack_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Engagement + learning_and_training +communication+ Advanced_course+ course_link+anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Advanced_course"}
   - slot{"quickreply_value32":"Advanced_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training +communication+ Advanced_course+ course_link+anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Communication_skills"}
   - slot{"quickreply_value31":"Communication_skills"}
   - utter_Learning_communication
* quickreply32{"quickreply_value32":"Advanced_course"}
   - slot{"quickreply_value32":"Advanced_course"}
   - utter_training_communication
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Engagement + learning_and_training + Daycare + Beginner_Daycare_course +course_link+ anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Beginner_Daycare_course"}
   - slot{"quickreply_value36":"Beginner_Daycare_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training + Daycare + Beginner_Daycare_course +course_link+ anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Beginner_Daycare_course"}
   - slot{"quickreply_value36":"Beginner_Daycare_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart


## welcome message + Engagement + learning_and_training + Daycare + Intermediate_Daycare_course +course_link+ anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Intermediate_Daycare_course"}
   - slot{"quickreply_value36":"Intermediate_Daycare_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training + Daycare + Intermediate_Daycare_course +course_link+ anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Intermediate_Daycare_course"}
   - slot{"quickreply_value36":"Intermediate_Daycare_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
 

## welcome message + Engagement + learning_and_training + Daycare + Advanced_course +course_link+ anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Advanced_course"}
   - slot{"quickreply_value36":"Advanced_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training + Daycare + Advanced_course +course_link+ anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Advanced_course"}
   - slot{"quickreply_value36":"Advanced_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart

## welcome message + Engagement + learning_and_training + Daycare + Fasttrack_course +course_link+ anything_else_yes
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Fasttrack_course"}
   - slot{"quickreply_value36":"Fasttrack_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart

## welcome message + Engagement + learning_and_training + Daycare + Fasttrack_course +course_link+ anything_else_no
* get_started
   - utter_welcome_message
* Number{"phone_no": "8792208625"}
   - slot{"phone_no": "8792208625"}
   - utter_otp 
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"learning_and_training"}
   - slot{"quickreply_value12":"learning_and_training"}
   - utter_Learning_Training
* quickreply31{"quickreply_value31":"Daycare_skills"}
   - slot{"quickreply_value31":"Daycare_skills"}
   - utter_Learning_Daycare
* quickreply36{"quickreply_value36":"Fasttrack_course"}
   - slot{"quickreply_value36":"Fasttrack_course"}
   - utter_training_daycare
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   
## welcome message + Engagement + Grievance_reporting_and_management + loose_identity_card + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"grievance_reporting_and_management"}
   - slot{"quickreply_value12":"grievance_reporting_and_management"}
   - utter_report_type
   - utter_report_issue
* quickreply27{"quickreply_value27":"lost_identity_card"}
   - slot{"quickreply_value27":"lost_identity_card"}
   - utter_loose_identity
   - action_date_validate
* Number{"phone_no": "1"}
   - slot{"phone_no": "1"}
   - action_grievance_reporting_and_management_identity_validate
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement + Grievance_reporting_and_management + loose_identity_card + anything_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"grievance_reporting_and_management"}
   - slot{"quickreply_value12":"grievance_reporting_and_management"}
   - utter_report_type
   - utter_report_issue
* quickreply27{"quickreply_value27":"lost_identity_card"}
   - slot{"quickreply_value27":"lost_identity_card"}
   - utter_loose_identity
   - action_date_validate
* Number{"phone_no": "1"}
   - slot{"phone_no": "1"}
   - action_grievance_reporting_and_management_identity_validate
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart
   

## welcome message + Engagement + Grievance_reporting_and_management + loose_access_card +anythin_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"grievance_reporting_and_management"}
   - slot{"quickreply_value12":"grievance_reporting_and_management"}
   - utter_report_type
   - utter_report_issue
* quickreply27{"quickreply_value27":"lost_access_card"}
   - slot{"quickreply_value27":"lost_access_card"}
   - utter_loose_access
   - action_date_validate
* Number{"phone_no": "1"}
   - slot{"phone_no": "1"}
   - action_grievance_reporting_and_management_access_validate
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement + Grievance_reporting_and_management + loose_access_card +anythin_elseNo
* get_started
   - utter_welcome_message
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"grievance_reporting_and_management"}
   - slot{"quickreply_value12":"grievance_reporting_and_management"}
   - utter_report_type
   - utter_report_issue
* quickreply27{"quickreply_value27":"lost_access_card"}
   - slot{"quickreply_value27":"lost_access_card"}
   - utter_loose_access
   - action_date_validate
* Number{"phone_no": "1"}
   - slot{"phone_no": "1"}
   - action_grievance_reporting_and_management_access_validate
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart



## welcome message + Engagement + Grievance_reporting_and_management + other_complaint + anythin_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"grievance_reporting_and_management"}
   - slot{"quickreply_value12":"grievance_reporting_and_management"}
   - utter_report_type
   - utter_report_issue
* quickreply27{"quickreply_value27":"other_complaints"}
   - slot{"quickreply_value27":"other_complaints"}
   - utter_other_complaint
* quickreply28{"custom_messege":"i"}
   - slot{"custom_messege": "i"}
   - action_other_complaint
   - utter_complainet
   - utter_anything_else
* quickreply50{"quickreply_value50":"affirm"}
  - slot{"quickreply_value50":"affirm"}
  - action_restart
  
## welcome message + Engagement + Grievance_reporting_and_management + other_complaint + anythin_elseYes
* get_started
   - utter_welcome_message
* Number{"phone_no": "123456"}
   - slot{"phone_no": "123456"}
   - utter_thankyou
   - utter_main
* quickreply{"quickreply_value":"Engagement"}
   - slot{"quickreply_value":"Engagement"}
   - utter_Engagement
* quickreply12{"quickreply_value12":"grievance_reporting_and_management"}
   - slot{"quickreply_value12":"grievance_reporting_and_management"}
   - utter_report_type
   - utter_report_issue
* quickreply27{"quickreply_value27":"other_complaints"}
   - slot{"quickreply_value27":"other_complaints"}
   - utter_other_complaint
* quickreply28{"custom_messege":"i"}
   - slot{"custom_messege": "i"}
   - action_other_complaint
   - utter_complainet
   - utter_anything_else
* quickreply50{"quickreply_value50":"deny"}
   - slot{"quickreply_value50":"deny"}
   - utter_employe_feedback
* quickreply3{"quickreply_value3":"Number"}
   - slot{"quickreply_value3":"Number"} 
   - utter_thankyou_feedback
   - action_restart


