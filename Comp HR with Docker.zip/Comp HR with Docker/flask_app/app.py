
from flask import Flask  
from flask import render_template
from flask_ngrok import run_with_ngrok
from flask_cors import CORS,cross_origin
# export FLASK_RUN_PORT=5000


# creates a Flask application with name "app"
app = Flask(__name__, static_url_path='/static')
app.config['CORS_HEADERS'] = 'Content-Type'
CORS(app, resources={r"*": {"origins": "*"}})

# run_with_ngrok(app)

# a route to display our html page called "index.html" gotten from [react-chat-widget](https://github.com/mrbot-ai/rasa-webchat)
@app.route("/")
@cross_origin()
def index():  
    return render_template('index.html')

# run the applicatio
if __name__ == "__main__":
 
    app.run(host="0.0.0.0",port="8000",debug=False)
    #app.run(debug=False)


